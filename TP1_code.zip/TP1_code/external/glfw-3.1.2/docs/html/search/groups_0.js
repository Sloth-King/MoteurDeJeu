var searchData=
[
  ['context_20handling',['Context handling',['../group__context.html',1,'']]]
];
